import React, { Component } from 'react';
import axios from 'axios';



class ContentArea extends Component {

    state = {
        persons: []
    }

    componentDidMount() {
        axios.get(`https://jsonplaceholder.typicode.com/photos`)
            .then(res => {
                const persons = res.data;
                this.setState({ persons });
            })
    }

    render() {


        return (


            <React-Fragment>
                <div className='contentSection'>

                    <div className="polaroid">
                        <img src="lights600x400.jpg" />
                        <div className="boxcontainer">
                            <div>This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</div>
                            <div className="btn-group">
                                <button type="button" className="btn btn-default btn-md">View</button>
                                <button type="button" className="btn btn-default btn-md">Edit</button>
                            </div>
                            <div className='time'>9 min</div>
                        </div>
                    </div>

                </div>
            </React-Fragment>
        )

    }

}

export default ContentArea;

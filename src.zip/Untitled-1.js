import React from "react";

import './App.css';
import TopSection from './tty';

import 'bootstrap/dist/css/bootstrap.min.css';

const App = () => (
  <Router>
    <div>
      <Header />
      <Route exact path="/" component={TopSection} params={} />
      <Route exact path="/Features" component={Features} />
      <Route path="/about" component={About} />
      <Route path="/topics" component={Topics} />
    </div>
  </Router>
);

/*
const Logo = () =>(
 
)
*/
const Features = () => (
  <div className="top_section">
    <top data="kljklkllj" />
  </div>
);



const About = () => <h2>About</h2>;
const Topic = ({ match }) => <h3>Requested Param: {match.params.id}</h3>;
const Topics = ({ match }) => (
  <div>
    <h2>Topics</h2>
    <ul>
      <li>
        <Link to={`${match.url}/components`}>Components</Link>
      </li>
      <li>
        <Link to={`${match.url}/props-v-state`}>Props v. State</Link>
      </li>
    </ul>
    <Route path={`${match.path}/:id`} component={Topic} />
    <Route
      exact
      path={match.path}
      render={() => <h3>Please select a topic.</h3>}
    />
  </div>
);
const Header = () => (


  <div className='navigation'>
   <div className='logo'><span> <Link to="/">Compunnel</Link></span></div> 
  <ul className='nav_menu'>
    <li>
      <Link to="/Features">Features</Link>
    </li>
    <li>
      <Link to="/about">Enterprise</Link>
    </li>
    <li>
      <Link to="/topics">Support</Link>
    </li>
    <li>
      <Link to="/topics">Pricing</Link>
    </li>
  </ul>
  </div>
);

   


export default App;
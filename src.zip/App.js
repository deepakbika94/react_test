import React, {Component} from "react";
import { BrowserRouter as Router, Route, Link } from "react-router-dom";
import './App.css';
import Routes from './views'
import Header from './Header';
import ContentArea from './ContentArea';



import 'bootstrap/dist/css/bootstrap.min.css';

//const App = () => (
class App extends Component{

  render(){
    return(
        <div>
          <Router>
            <React.Fragment>
              <Header />
              <Routes />
              <ContentArea />
            
            </React.Fragment>
          </Router>
          
        </div>
    )
  }
};




export default App;

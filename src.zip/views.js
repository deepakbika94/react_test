import React, {Component} from "react";
import { Route } from "react-router-dom";
import TopSection from './tty';
import Features from './Features';


class Routes extends Component{

    render(){
      return(
          <div>
            <Route exact path='/' component={TopSection}></Route>
            <Route path='/Features' component={Features}></Route>
            <Route path='/Features/:id' component={Features}></Route>
          </div>
      )
    }
  };
  
  
  
  
  export default Routes;


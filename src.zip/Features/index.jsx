import React, { Component } from 'react';

class Features extends Component {

    render(){
        return(
            <div className="top_section">
                <h3>Features example</h3>
                <p>Something short and leading about the collection below—its contents, the creator, etc. Make it short and sweet, but not too short so folks don't simply skip over it entirely.</p>
                <button className='btn btn-primary'>Main call to action</button><button className='btn btn-default active'>Second action</button>
          </div>
        )
    };
}

export default Features;
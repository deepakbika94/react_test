import React, { Component } from 'react';
import { Link } from "react-router-dom";


class Header extends Component {

    render(){
        return(
            <div className='navigation'>
               <div className='logo'><span> <Link to="/">Compunnel</Link></span></div>
                <ul className='nav_menu'>
                    <li><Link to="/Features">Features</Link></li>
                    <li><Link to="/about">Enterprise</Link></li>
                    <li><Link to="/topics">Support</Link></li>
                    <li><Link to="/topics">Pricing</Link></li>
                </ul>
           </div>
        )
    };
}

export default Header;